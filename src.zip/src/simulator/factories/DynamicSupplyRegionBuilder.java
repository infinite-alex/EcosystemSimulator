package simulator.factories;

import org.json.JSONObject;

import simulator.misc.Vector2D;
import simulator.model.Region;

public class DynamicSupplyRegionBuilder implements Builder<Region> {

    @Override
    public String getType() {
        return "dynamic";
    }

    @Override
    public Region createInstance(JSONObject data) {

        double x = data.getDouble("x");
        double y = data.getDouble("y");
        double food = data.getDouble("food");
        double factor = data.getDouble("factor");

        return new DynamicSupplyRegion(new Vector2D(x, y),food,factor);
    }
    protected void fillInData(JSONObject data) 
    {  
    	data.put("factor", "food increase factor");
    	data.put("food", "initial amount of food (optional, default 100.0)");
    }
    


}
