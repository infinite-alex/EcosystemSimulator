package simulator.launcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.control.Controller;
import simulator.factories.Builder;
import simulator.factories.DynamicSupplyRegionBuilder;
import simulator.misc.*;
import simulator.model.*;
import simulator.strategies.*;
import simulator.view.MainWindow;

import javax.swing.*;

public class Main {

	private enum ExecMode {
		BATCH("batch", "Batch mode"), GUI("gui", "Graphical User Interface mode");

		private String tag;
		private String desc;

		private ExecMode(String modeTag, String modeDesc) {
			tag = modeTag;
			desc = modeDesc;
		}

		public String getTag() {
			return tag;
		}

		public String getDesc() {
			return desc;
		}
	}

	// default values for some parameters
	//
	private final static Double DEFAULT_TIME = 10.0; // in seconds

	// some attributes to stores values corresponding to command-line parameters
	//
	private static Double time = null;
	private static String inFile = null;
	private static ExecMode mode = ExecMode.GUI;
	public static Factory<Animal> animalsFactory;
	public static Factory<Region> regionsFactory;
	public static double dt = 0.03;

	private static void parseArgs(String[] args) {

		// define the valid command line options
		//
		Options cmdLineOptions = buildOptions();

		// parse the command line as provided in args
		//
		CommandLineParser parser = new DefaultParser();
		try {
			CommandLine line = parser.parse(cmdLineOptions, args);
			parseHelpOption(line, cmdLineOptions);
			parseInFileOption(line);
			parseTimeOption(line);

			// if there are some remaining arguments, then something wrong is
			// provided in the command line!
			//
			String[] remaining = line.getArgs();
			if (remaining.length > 0) {
				String error = "Illegal arguments:";
				for (String o : remaining)
					error += (" " + o);
				throw new ParseException(error);
			}

		} catch (ParseException e) {
			System.err.println(e.getLocalizedMessage());
			System.exit(1);
		}

	}

	private static Options buildOptions() {
		Options cmdLineOptions = new Options();

		// help
		cmdLineOptions.addOption(Option.builder("h").longOpt("help").desc("Print this message.").build());

		// input file
		cmdLineOptions.addOption(Option.builder("i").longOpt("input").hasArg().desc("A configuration file.").build());

		// steps
		cmdLineOptions.addOption(Option.builder("t").longOpt("time").hasArg()
				.desc("A real number representing the total simulation time in seconds. Default value: "
						+ DEFAULT_TIME + ".")
				.build());

		return cmdLineOptions;
	}
	
	private static void initFactories() {

	    List<Builder<SelectionStrategy>> stratBuilders = new ArrayList<>();
	    stratBuilders.add(new SelectFirstBuilder());
	    stratBuilders.add(new SelectClosestBuilder());
	    stratBuilders.add(new SelectYoungestBuilder());

	    Factory<SelectionStrategy> strategyFactory =
	            new BuilderBasedFactory<>(stratBuilders);

	    List<Builder<Animal>> animalBuilders = new ArrayList<>();
	    animalBuilders.add(new SheepBuilder(strategyFactory));
	    animalBuilders.add(new WolfBuilder(strategyFactory));

	    animalsFactory = new BuilderBasedFactory<>(animalBuilders);

	    List<Builder<Region>> regionBuilders = new ArrayList<>();
	    regionBuilders.add(new DefaultRegionBuilder());
	    regionBuilders.add(new DynamicSupplyRegionBuilder());

	    regionsFactory = new BuilderBasedFactory<>(regionBuilders);
	}
	
	private static void startBatchMode() throws Exception {

	    InputStream is = new FileInputStream(new File(inFile));
	    JSONObject input = loadJSONFile(is);
	    
	    //TODO: Create an OutputStream similar to InputStream with the value  bound to outFIle
	    
	    int cols = input.getInt("cols");
	    int rows = input.getInt("rows");
	    int width = input.getInt("width");
	    int height = input.getInt("height");

	    Simulator sim = new Simulator(
	            cols, rows, width, height,
	            animalsFactory,
	            regionsFactory
	    );

	    Controller ctrl = new Controller(sim);

	    ctrl.loadData(input);

	    ctrl.run(time, dt, true, System.out);
	}
	
	private static void parseHelpOption(CommandLine line, Options cmdLineOptions) {
		if (line.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp(Main.class.getCanonicalName(), cmdLineOptions, true);
			System.exit(0);
		}
	}

	private static void parseInFileOption(CommandLine line) throws ParseException {
		inFile = line.getOptionValue("i");
		if (mode == ExecMode.BATCH && inFile == null) {
			throw new ParseException("In batch mode an input configuration file is required");
		}
	}

	private static void parseTimeOption(CommandLine line) throws ParseException {
		String t = line.getOptionValue("t", DEFAULT_TIME.toString());
		try {
			time = Double.parseDouble(t);
			assert (time >= 0);
		} catch (Exception e) {
			throw new ParseException("Invalid value for time: " + t);
		}
	}

	private static JSONObject loadJSONFile(InputStream in) {
		return new JSONObject(new JSONTokener(in));
	}

	private static void startGUIMode() throws Exception {
	    InputStream is = new FileInputStream(new File(inFile));
	    JSONObject input = loadJSONFile(is);

	    int cols = input.getInt("cols");
	    int rows = input.getInt("rows");
	    int width = input.getInt("width");
	    int height = input.getInt("height");

	    Simulator sim = new Simulator(
	            cols, rows, width, height,
	            animalsFactory,
	            regionsFactory
	    );

	    Controller ctrl = new Controller(sim);

	    

	    SwingUtilities.invokeLater(() -> {
	        new MainWindow(ctrl);  
	    });
	    ctrl.loadData(input);
	}

	private static void start(String[] args) throws Exception {
		initFactories();
		parseArgs(args);
		switch (mode) {
		case BATCH:
			startBatchMode();
			break;
		case GUI:
			startGUIMode();
			break;
		}
	}

	public static void main(String[] args) {
		Utils.RAND.setSeed(2147483647l);
		try {
			start(args);
		} catch (Exception e) {
			System.err.println("Something went wrong ...");
			System.err.println();
			e.printStackTrace();
		}
	}
}

