package simulator.model;
import java.util.*;
import org.json.JSONObject;

import simulator.misc.Factory;

public class Simulator implements JSONable {

    private RegionManager regionManager;
    private List<Animal> animals;
    private Factory<Animal> animalsFactory;
    private Factory<Region> regionsFactory;
    private double time;

    public Simulator(int cols, int rows, int width, int height, Factory<Animal> animalsFactory, Factory<Region> regionsFactory) {
        this.animalsFactory = animalsFactory;
        this.regionsFactory = regionsFactory;
        this.regionManager = new RegionManager(cols, rows, width, height);
        this.animals = new ArrayList<>();
        this.time = 0.0;
    }

    private void setRegion(int row, int col, Region r) {
        regionManager.setRegion(row, col, r);
    }

    public void setRegion(int row, int col, JSONObject rJson) {
        Region r = regionsFactory.createInstance(rJson);
        setRegion(row, col, r);
    }

    private void addAnimal(Animal a) {
        animals.add(a);
        regionManager.registerAnimal(a);
    }

    public void addAnimal(JSONObject aJson) {
        Animal a = animalsFactory.createInstance(aJson);
        addAnimal(a);
    }

    public AnimalMapView getMapInfo() {
        return regionManager;
    }
    
    public List<? extends AnimalInfo> getAnimals() {
        return Collections.unmodifiableList(animals);
    }

    public double getTime() {
        return time;
    }

    public void advance(double dt)
    {
        time += dt;
        animals.removeIf(a -> {
            if (a.getState() == State.DEAD) {
                regionManager.unregisterAnimal(a);
                return true;
            }
            return false;
        });

        for (Animal a : new ArrayList<>(animals)) {
            a.update(dt);
            regionManager.updateAnimalRegion(a);
        }

        regionManager.updateAllRegions(dt);

        for (Animal a : new ArrayList<>(animals)) {
            if (a.isPregnant()) {
                Animal baby = a.deliverBaby();
                addAnimal(baby);
            }
        }
    }


    @Override
    public JSONObject asJSON() {
        JSONObject json = new JSONObject();
        json.put("time", time);
        json.put("state", regionManager.asJSON());
        return json;
    }

}