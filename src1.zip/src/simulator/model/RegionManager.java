package simulator.model;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Vector2D;

public class RegionManager implements AnimalMapView {

    private int width, height;      
    private int cols, rows;         
    private double cellWidth, cellHeight; 
    private Region[][] regions;     
    private Map<Animal, Region> animalRegion; 
    private List<Animal> animals;  


    public RegionManager(int cols, int rows, int width, int height) {
        this.cols = cols;
        this.rows = rows;
        this.width = width;
        this.height = height;

        this.cellWidth = (double) width / cols;
        this.cellHeight = (double) height / rows;


        regions = new Region[rows][cols];
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                double x = c * cellWidth + cellWidth / 2.0;
                double y = r * cellHeight + cellHeight / 2.0;
                regions[r][c] = new DefaultRegion(new Vector2D(x, y));
            }
        }
        animalRegion = new HashMap<>();
        animals = new ArrayList<>();
    }
    public void setRegion(int row, int col, Region r) {
        Region old = regions[row][col];
        for (Animal a : old.getAnimals()) {
            r.addAnimal(a);
            animalRegion.put(a, r);
        }
        regions[row][col] = r;
    }
    public void registerAnimal(Animal a) {
        int col = (int) (a.getPosition().getX() / cellWidth);
        int row = (int) (a.getPosition().getY() / cellHeight);

        Region r = regions[row][col];
        r.addAnimal(a);
        animalRegion.put(a, r);
        animals.add(a);
        a.init(this);
    }
    public void unregisterAnimal(Animal a) {
        Region r = animalRegion.get(a);
        if (r != null) {
            r.removeAnimal(a);
            animalRegion.remove(a);
            animals.remove(a);
        }
    }

    public void updateAnimalRegion(Animal a) {
        int col = (int) (a.getPosition().getX() / cellWidth);
        int row = (int) (a.getPosition().getY() / cellHeight);

        Region newRegion = regions[row][col];
        Region oldRegion = animalRegion.get(a);

        if (oldRegion != newRegion) {
            oldRegion.removeAnimal(a);
            newRegion.addAnimal(a);
            animalRegion.put(a, newRegion);
        }
    }
    @Override
    public double getFood(Animal a, double dt) {
        Region r = animalRegion.get(a);
        if (r == null) return 0.0;
        return r.getFood(a, dt);
    }
    public void updateAllRegions(double dt) {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                regions[r][c].update(dt);
            }
        }
    }

    @Override
    public List<Animal> getAnimalsinRange(Animal a, double range) {
        List<Animal> result = new ArrayList<>();
        int colCenter = (int) (a.getPosition().getX() / cellWidth);
        int rowCenter = (int) (a.getPosition().getY() / cellHeight);
        for (int r = Math.max(0, rowCenter - 1); r <= Math.min(rows - 1, rowCenter + 1); r++) {
            for (int c = Math.max(0, colCenter - 1); c <= Math.min(cols - 1, colCenter + 1); c++) {
                for (Animal other : regions[r][c].getAnimals()) {
                    if (other != a && a.getPosition().distanceTo(other.getPosition()) <= range) {
                        result.add(other);
                    }
                }
            }
        }

        return result;
    }

    @Override
    public List<Animal> getAnimals() {
        return animals;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    public JSONObject asJSON() {
        JSONObject json = new JSONObject();
        JSONArray arr = new JSONArray();

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                JSONObject regionObj = new JSONObject();
                regionObj.put("row", r);
                regionObj.put("col", c);
                regionObj.put("data", regions[r][c].asJSON());
                arr.put(regionObj);
            }
        }

        json.put("regions", arr);
        return json;
    }

}