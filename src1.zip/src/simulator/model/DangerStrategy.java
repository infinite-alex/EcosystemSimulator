package simulator.model;

public class DangerStrategy {

}
