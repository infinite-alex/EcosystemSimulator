package simulator.model;
import org.json.JSONObject;
import simulator.strategies.SelectionStrategy;
import simulator.factories.Builder;
import simulator.misc.Factory;
import simulator.misc.Vector2D;


public class WolfBuilder implements Builder<Animal> {

    private Factory<SelectionStrategy> strategyFactory;

    public WolfBuilder(Factory<SelectionStrategy> strategyFactory) {
        this.strategyFactory = strategyFactory;
    }

    @Override
    public String getType() {
        return "wolf";
    }
    
    @Override
    public Animal createInstance(JSONObject data) {
        SelectionStrategy strat = strategyFactory.createInstance(data.getJSONObject("strategy"));
        Vector2D pos = new Vector2D(
                data.getDouble("x"), 
                data.getDouble("y")
            );
            SelectionStrategy mateStrat = strat;
            SelectionStrategy huntStrat = strat;
            return new Wolf(mateStrat, huntStrat, pos);
    }
}