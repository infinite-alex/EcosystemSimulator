package simulator.model;

import org.json.JSONObject;
import simulator.factories.Builder;

public class DefaultRegionBuilder implements Builder<Region> {

    @Override
    public String getType() {
        return "default";
    }

    @Override
    public Region createInstance(JSONObject data) {
        return new DefaultRegion(null);
    }
}