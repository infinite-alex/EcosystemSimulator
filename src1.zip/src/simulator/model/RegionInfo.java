package simulator.model;

public interface RegionInfo extends JSONable {  
	// for now it is empty, later we will make it implement the interface  
	// Iterable<AnimalInfo>  
	/*It is an interface that defines what information
	 *  can be seen about a region and includes methods 
	 *  that query the state of the region but never modify it. 
	 *  For now, the interface only extends JSONable, later
	 *   we will add more methods.
	 * 
	 */
}
