package simulator.model;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import simulator.misc.Vector2D;
import org.json.JSONArray;
import org.json.JSONObject;

public abstract class Region implements Entity, FoodSupplier, RegionInfo {

    protected List<Animal> animals;
    protected Vector2D position;
    protected Region(Vector2D position) {
        this.position = position;
        animals = new ArrayList<>();
    }

    @Override
    public Vector2D getPosition() {
        return position;
    }

    protected final void addAnimal(Animal a) {
        animals.add(a);
    }

    protected final void removeAnimal(Animal a) {
        animals.remove(a);
    }
    public abstract void update(double dt);

    public final List<Animal> getAnimals() {
        return Collections.unmodifiableList(animals);
    }

    @Override
    public JSONObject asJSON() {
        JSONObject json = new JSONObject();
        JSONArray arr = new JSONArray();

        for (Animal a : animals) {
            arr.put(a.asJSON());
        }

        json.put("animals", arr);
        return json;
    }
}
    
    
/*
 * final void addAnimal(Animal a): adds animal a to the list of animals.

final void removeAnimal(Animal a): removes 
the animal from the list of animals.

final List<Animal> getAnimals(): returns an 
unmodifiable version of the list of animals.

public JSONObject asJSON(): returns a JSON 
structure like the following
 where ai is what asJSON() of the corresponding animal returns:
 */
