
package simulator.model;

import java.util.List;

public interface AnimalMapView {
    int getWidth();
    int getHeight();
    double getFood(Animal a, double dt);
    List<Animal> getAnimals();
    List<Animal> getAnimalsinRange(Animal a, double range);
}