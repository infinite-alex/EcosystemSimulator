package simulator.factories;

// deci in default region a avut ca animalele mancau si acum noi
//facem sa mai creasca sau ca se schimba

import simulator.misc.Vector2D;
import simulator.model.Animal;
import simulator.model.AnimalInfo;
import simulator.model.Diet;
import simulator.model.Region;

public class DynamicSupplyRegion extends Region {
	private double food;
	private double factor;
	
    public DynamicSupplyRegion(Vector2D position, double food, double factor) {
        super(position);     // ← OBLIGATORIU
        this.food = food;
        this.factor = factor;
    }	
    @Override
	public double getFood(Animal a, double dt) {
		if ( a.getDiet() == Diet.CARNIVORE)
			return 0.0;
		
		int n=0;
		for (int i = 0; i < animals.size(); i++) {
		    Animal current = animals.get(i);
		    if (current.getDiet() == Diet.HERBIVORE) {
		        n++;
		    }
		}
		
		double amount = 60.0 * Math.exp(-Math.max(0, n - 5.0) * 2.0) * dt;
        double eaten = Math.min(food, amount);
        food -= eaten;

        return eaten;	
	}
    @Override
    public void update(double dt) {
        if (Math.random() < 0.5) {
            food += dt * factor;
        }
    }
}
