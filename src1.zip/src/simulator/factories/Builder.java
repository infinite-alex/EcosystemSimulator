package simulator.factories;

import org.json.JSONObject;

public interface Builder<T> {
    String getType();
    T createInstance(JSONObject data);
}