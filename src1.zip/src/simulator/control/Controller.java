package simulator.control;
import java.io.OutputStream;
import java.io.PrintStream;
import org.json.JSONObject;

import org.json.JSONArray;

import simulator.model.Simulator;

public class Controller {
	private Simulator sim;
	
	public Controller(Simulator sim) {
	    this.sim=sim;
	}
    public void loadData(JSONObject data) {
    	
        if (data.has("regions")) {
            JSONArray regions = data.getJSONArray("regions");

            for (int i = 0; i < regions.length(); i++) {
                JSONObject r = regions.getJSONObject(i);

                JSONArray row = r.getJSONArray("row");
                JSONArray col = r.getJSONArray("col");
                JSONObject spec = r.getJSONObject("spec");

                for (int rf = row.getInt(0); rf <= row.getInt(1); rf++) {
                    for (int cf = col.getInt(0); cf <= col.getInt(1); cf++) {
                        sim.setRegion(rf, cf, spec);
                    }
                }
            }
        }
        JSONArray animals = data.getJSONArray("animals");

        for (int i = 0; i < animals.length(); i++) {
            JSONObject a = animals.getJSONObject(i);
            int amount = a.getInt("amount");
            JSONObject spec = a.getJSONObject("spec");

            for (int j = 0; j < amount; j++) {
                sim.addAnimal(spec);
            }
        }
    }
    public void run(double t, double dt, boolean sv, OutputStream out) {
    	
        JSONObject initState = sim.asJSON();

        while (sim.getTime() <= t) {
            sim.advance(dt);
        }

        JSONObject finalState = sim.asJSON();

        JSONObject result = new JSONObject();
        result.put("in", initState);
        result.put("out", finalState);

        PrintStream p = new PrintStream(out);
        p.print(result.toString(2));
    }
}