package simulator.strategies;

import org.json.JSONObject;

import simulator.factories.Builder;

public class SelectClosestBuilder implements Builder<SelectionStrategy> {

    @Override
    public String getType() {
        return "closest";
    }

    @Override
    public SelectionStrategy createInstance(JSONObject data) {
        return new SelectClosest();
    }
}