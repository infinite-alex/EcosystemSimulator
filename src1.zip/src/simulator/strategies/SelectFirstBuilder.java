package simulator.strategies;

import org.json.JSONObject;

import simulator.factories.Builder;

public class SelectFirstBuilder implements Builder<SelectionStrategy> {

    public String getType() {
        return "first";
    }

    public SelectionStrategy createInstance(JSONObject data) {
        return new SelectFirst();
    }
}