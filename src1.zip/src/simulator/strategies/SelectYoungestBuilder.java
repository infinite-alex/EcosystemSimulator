package simulator.strategies;

import org.json.JSONObject;

import simulator.factories.Builder;

public class SelectYoungestBuilder implements Builder<SelectionStrategy> {

    @Override
    public String getType() {
        return "youngest";
    }

    @Override
    public SelectionStrategy createInstance(JSONObject data) {
        return new SelectYoungest();
    }
}