package simulator.misc;

import java.util.List;

import org.json.JSONObject;

public interface Factory<T> {
    T createInstance(JSONObject info);
    List<JSONObject> getInfo();
}