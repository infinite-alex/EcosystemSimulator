package simulator.misc;
import java.util.List;
import org.json.JSONObject;

import simulator.factories.Builder;

public class BuilderBasedFactory<T> implements Factory<T> {

    private List<Builder<T>> builders;

    public BuilderBasedFactory(List<Builder<T>> builders) {
        this.builders = builders;
    }

    @Override
    public T createInstance(JSONObject data) {
        String type = data.getString("type");

        for (Builder<T> b : builders) {
            if (b.getType().equals(type)) {
                return b.createInstance(data);
            }
        }

        throw new IllegalArgumentException("Unknown type: " + type);
    }

	@Override
	public List<JSONObject> getInfo() {
		// TODO Auto-generated method stub
		return null;
	}
}